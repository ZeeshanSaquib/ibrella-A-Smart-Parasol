#pragma once
#ifdef MT9D111
void editRegs(uint8_t microedit);
#else
void editRegs(void);
#endif
