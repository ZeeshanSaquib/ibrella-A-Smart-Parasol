#pragma once
#include "ff.h"
extern FATFS FatFs;		/* FatFs work area needed for each volume */
