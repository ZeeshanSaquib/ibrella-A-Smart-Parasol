#pragma once
#include "config.h"
#ifdef haveSDcard
void browserSD(void);
#endif
