#pragma once
#include <stdint.h>
#include <avr/pgmspace.h>
extern const uint16_t exit_icon[] PROGMEM;
