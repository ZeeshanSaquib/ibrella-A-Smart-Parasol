#pragma once
#include "config.h"
#ifdef MT9D111
//extern const struct regval_listP MT9D111_init[];
#endif
