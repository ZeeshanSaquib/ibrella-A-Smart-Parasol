#pragma once
void gammaEdit(void);
