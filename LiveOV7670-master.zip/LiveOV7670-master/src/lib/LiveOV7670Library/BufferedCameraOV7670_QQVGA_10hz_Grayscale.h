//
// Created by indrek on 30.04.2016.
//

#ifndef _BUFFEREDCAMERAOV7670_QQVGA_10HZ_GRAYSCALE_H
#define _BUFFEREDCAMERAOV7670_QQVGA_10HZ_GRAYSCALE_H

#include "BufferedCameraOV7670.h"


// 160 x 120 @ 10Hz
class BufferedCameraOV7670_QQVGA_10hz_Grayscale : public BufferedCameraOV7670<uint8_t, 160, uint8_t, 160, uint8_t, 120> {


public:
    BufferedCameraOV7670_QQVGA_10hz_Grayscale() : BufferedCameraOV7670(Resolution::RESOLUTION_QQVGA_160x120, CameraOV7670::PIXEL_YUV422, 0) {};

  inline void readLine() override __attribute__((always_inline));


private:
  inline void readPixels_unrolled_x160(uint16_t byteIndex) __attribute__((always_inline));
  inline void readPixels_unrolled_x10(uint16_t byteIndex) __attribute__((always_inline));
  inline void readPixel_unrolled(uint16_t byteIndex) __attribute__((always_inline));

};




void BufferedCameraOV7670_QQVGA_10hz_Grayscale::readLine() {
  pixelBuffer.writeBufferPadding = 0;
  waitForPixelClockLow();

  asm volatile("nop");
  asm volatile("nop");
  asm volatile("nop");

  for (uint8_t i = 0; i<160; i++) {
    pixelBuffer.readBuffer[i] = readPixelByte();
    asm volatile("nop");
    asm volatile("nop");
    asm volatile("nop");
    asm volatile("nop");
    asm volatile("nop");
    asm volatile("nop");
  }
}





#endif //_BUFFEREDCAMERAOV7670_QQVGA_10HZ_GRAYSCALE_H
